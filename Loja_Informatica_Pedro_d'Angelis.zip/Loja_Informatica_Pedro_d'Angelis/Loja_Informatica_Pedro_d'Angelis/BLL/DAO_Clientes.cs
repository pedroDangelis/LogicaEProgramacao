﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Loja_Informatica_Pedro_d_Angelis.BLL
{
    internal class DAO_Clientes
    {
    }
}
