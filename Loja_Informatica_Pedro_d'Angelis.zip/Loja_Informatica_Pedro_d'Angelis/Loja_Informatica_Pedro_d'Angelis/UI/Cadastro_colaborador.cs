﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Loja_Informatica_Pedro_d_Angelis
{
    public partial class Cadastro_colaborador : Form
    {
        public Cadastro_colaborador()
        {
            InitializeComponent();
        }

        private void Cadastro_colaborador_Load(object sender, EventArgs e)
        {

        }
    }
}
