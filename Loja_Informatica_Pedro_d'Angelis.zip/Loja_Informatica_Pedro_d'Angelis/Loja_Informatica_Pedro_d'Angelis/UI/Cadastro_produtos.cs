﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Loja_Informatica_Pedro_d_Angelis
{
    public partial class Cadastro_produtos : Form
    {
        public Cadastro_produtos()
        {
            InitializeComponent();
        }
    }
}
