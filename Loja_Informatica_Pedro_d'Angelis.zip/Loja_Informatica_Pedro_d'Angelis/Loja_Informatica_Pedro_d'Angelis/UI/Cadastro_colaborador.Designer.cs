﻿namespace Loja_Informatica_Pedro_d_Angelis
{
    partial class Cadastro_colaborador
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Cadastro_colaborador));
            this.btnCadastro = new System.Windows.Forms.Button();
            this.txtEnderecoColaborador = new System.Windows.Forms.TextBox();
            this.txtEmailColaborador = new System.Windows.Forms.TextBox();
            this.txtCpfColaborador = new System.Windows.Forms.TextBox();
            this.txtNomeColaborador = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtSalarioColaborador = new System.Windows.Forms.TextBox();
            this.txtCargoColaborador = new System.Windows.Forms.TextBox();
            this.txtTelefoneColaborador = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnCadastro
            // 
            this.btnCadastro.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnCadastro.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCadastro.Location = new System.Drawing.Point(231, 300);
            this.btnCadastro.Margin = new System.Windows.Forms.Padding(0);
            this.btnCadastro.Name = "btnCadastro";
            this.btnCadastro.Size = new System.Drawing.Size(166, 36);
            this.btnCadastro.TabIndex = 17;
            this.btnCadastro.Text = "Realizar cadastro";
            this.btnCadastro.UseVisualStyleBackColor = false;
            // 
            // txtEnderecoColaborador
            // 
            this.txtEnderecoColaborador.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEnderecoColaborador.Location = new System.Drawing.Point(6, 253);
            this.txtEnderecoColaborador.Name = "txtEnderecoColaborador";
            this.txtEnderecoColaborador.Size = new System.Drawing.Size(164, 26);
            this.txtEnderecoColaborador.TabIndex = 16;
            // 
            // txtEmailColaborador
            // 
            this.txtEmailColaborador.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmailColaborador.Location = new System.Drawing.Point(6, 191);
            this.txtEmailColaborador.Name = "txtEmailColaborador";
            this.txtEmailColaborador.Size = new System.Drawing.Size(164, 26);
            this.txtEmailColaborador.TabIndex = 15;
            // 
            // txtCpfColaborador
            // 
            this.txtCpfColaborador.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCpfColaborador.Location = new System.Drawing.Point(6, 131);
            this.txtCpfColaborador.Name = "txtCpfColaborador";
            this.txtCpfColaborador.Size = new System.Drawing.Size(120, 26);
            this.txtCpfColaborador.TabIndex = 14;
            // 
            // txtNomeColaborador
            // 
            this.txtNomeColaborador.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNomeColaborador.Location = new System.Drawing.Point(6, 67);
            this.txtNomeColaborador.Name = "txtNomeColaborador";
            this.txtNomeColaborador.Size = new System.Drawing.Size(164, 26);
            this.txtNomeColaborador.TabIndex = 13;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(3, 233);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 20);
            this.label4.TabIndex = 12;
            this.label4.Text = "Endereço:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 171);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 20);
            this.label3.TabIndex = 11;
            this.label3.Text = "E-mail:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 111);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 20);
            this.label2.TabIndex = 10;
            this.label2.Text = "CPF:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 20);
            this.label1.TabIndex = 9;
            this.label1.Text = "Nome: ";
            // 
            // txtSalarioColaborador
            // 
            this.txtSalarioColaborador.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSalarioColaborador.Location = new System.Drawing.Point(231, 253);
            this.txtSalarioColaborador.Name = "txtSalarioColaborador";
            this.txtSalarioColaborador.Size = new System.Drawing.Size(164, 26);
            this.txtSalarioColaborador.TabIndex = 23;
            // 
            // txtCargoColaborador
            // 
            this.txtCargoColaborador.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCargoColaborador.Location = new System.Drawing.Point(231, 191);
            this.txtCargoColaborador.Name = "txtCargoColaborador";
            this.txtCargoColaborador.Size = new System.Drawing.Size(164, 26);
            this.txtCargoColaborador.TabIndex = 22;
            // 
            // txtTelefoneColaborador
            // 
            this.txtTelefoneColaborador.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTelefoneColaborador.Location = new System.Drawing.Point(231, 131);
            this.txtTelefoneColaborador.Name = "txtTelefoneColaborador";
            this.txtTelefoneColaborador.Size = new System.Drawing.Size(166, 26);
            this.txtTelefoneColaborador.TabIndex = 21;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(228, 233);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(70, 20);
            this.label5.TabIndex = 20;
            this.label5.Text = "Salário:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(228, 171);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 20);
            this.label6.TabIndex = 19;
            this.label6.Text = "Cargo:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(228, 111);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(84, 20);
            this.label7.TabIndex = 18;
            this.label7.Text = "Telefone:";
            // 
            // Cadastro_colaborador
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(612, 345);
            this.Controls.Add(this.txtSalarioColaborador);
            this.Controls.Add(this.txtCargoColaborador);
            this.Controls.Add(this.txtTelefoneColaborador);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btnCadastro);
            this.Controls.Add(this.txtEnderecoColaborador);
            this.Controls.Add(this.txtEmailColaborador);
            this.Controls.Add(this.txtCpfColaborador);
            this.Controls.Add(this.txtNomeColaborador);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Cadastro_colaborador";
            this.Text = "Cadastro de colaboradores";
            this.Load += new System.EventHandler(this.Cadastro_colaborador_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCadastro;
        private System.Windows.Forms.TextBox txtEnderecoColaborador;
        private System.Windows.Forms.TextBox txtEmailColaborador;
        private System.Windows.Forms.TextBox txtCpfColaborador;
        private System.Windows.Forms.TextBox txtNomeColaborador;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtSalarioColaborador;
        private System.Windows.Forms.TextBox txtCargoColaborador;
        private System.Windows.Forms.TextBox txtTelefoneColaborador;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
    }
}