﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Loja_Informatica_Pedro_d_Angelis
{
    internal class Classe_Colaborador
    {
        public class Colaborador
        {
            private int Id_Colaborador;
            private string Nome_Colaborador;
            private string CPF_Colaborador;
            private string Email_Colaborador;
            private string Telefone_Colaborador;
            private string Endereco_Colaborador;
            private string Cargo_Colaborador;
            private string Salario_Colaborador;

            public int id_colaborador { get; set; }
            public string nome_colaborador { get; set; }
            public string cpf_colaborador { get; set; }
            public string email_colaborador { get; set; }
            public string telefone_colaborador { get; set; }
            public string cargo_colaborador { get; set; }
            public string salario_colaborador { get; set; }

        }
    }
}

// idColaborador, nome, cpf, email, telefone, endereco, cargo, salario