﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Loja_Informatica_Pedro_d_Angelis
{
    internal class Classe_Clientes
    {

        public class Cliente
        {
            private int Id_Cliente;
            private string Nome;
            private string CPF;
            private string Email;
            private string Endereco;

            public int id_cliente { get; set; }
            public string nome { get; set; }
            public string cpf { get; set; }
            public string email { get; set; }
            public string endereco { get; set; }
        }

    }
}
