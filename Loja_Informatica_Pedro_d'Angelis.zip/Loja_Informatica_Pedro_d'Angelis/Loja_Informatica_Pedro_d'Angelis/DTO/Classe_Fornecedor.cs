﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Loja_Informatica_Pedro_d_Angelis
{
    internal class Classe_Fornecedor
    {

        public class Fornecedor
        {
            private int Id_Fornecedor;
            private string Razao_Social;
            private string Endereco;
            private string Email;
            private string Telefone;
            private string CNPJ;
            private string Insc_Estadual;

            public int id_fornecedor { get; set; }
            public string razao_social { get; set; }
            public string endereco { get; set; }
            public string email { get; set; }
            public string telefone { get; set; }
            public string cnpj { get; set; }
            public string insc_estadual { get; set; }
        }

    }
}

//idfornecedores, razao_social, endereco, email, telefone, cnpj, insc/estadual
