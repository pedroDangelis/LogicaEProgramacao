﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Loja_Informatica_Pedro_d_Angelis
{
    internal class Classe_Pedidos
    {

        public class Pedidos
        {
            private int Id_Pedido;
            private int Id_Produto;
            private int Id_Fornecedor;
            private string Data_Pedido;
            private string Preco_Unitario;
            private string Quantidade;
            private string Total;
            private string Forma_Pagamento;

            public int id_pedido { get; set; }
            public int id_produto { get; set; }
            public int id_fornecedor { get; set; }
            public string data_pedido { get; set; }   
            public string preco_unitario { get; set; }
            public string quantidade { get; set; }
            public string total { get; set; }
            public string forma_pagamento { get; set; }


        }
    }
}

// idPedido, idproduto, idfornecedor, dataPedido, precoUnitario, quantidade, total, formaPagamento
