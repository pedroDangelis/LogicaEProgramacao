﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Loja_Informatica_Pedro_d_Angelis
{
    internal class Classe_Pagamento
    {
        public class Pagamento
        {
            private int Id_Pagamento;
            private string Tipo;

            public int id_pagamento { get; set; }
            public string tipo { get; set; }

        }
    }
}

//idPagamento, tipo