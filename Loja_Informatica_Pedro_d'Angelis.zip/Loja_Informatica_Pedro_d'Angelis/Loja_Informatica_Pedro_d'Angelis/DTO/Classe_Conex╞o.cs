﻿using System;
using MySql.Data.MySqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Conecão_CSharp
{
    internal class ClasseConexão
    {
        public MySqlConnection conexao = null;

        public MySqlConnection Conexao()
        {
            string conn = @"Persist Security Info = false;  
                            server = Localhost;
                            database = teste;
                            uid = root;
                            pwd = "; //definindo Atributos da Conexão(senha, servidor, login e etc)

            try
            {
                conexao = new MySqlConnection(conn);
                conexao.Open();                             //Realizando a Conexão
                Console.WriteLine(conexao.ToString());
            }
            catch (MySqlException)
            {
                throw new Exception("Problemas ao conectar no banco");      //capturando possiveis erros e retornando um aviso na tela
            }
            finally
            {
                conexao.Close();                            //encerrando a conexão ao fim do processo
            }
            return conexao;
        }
    }
}