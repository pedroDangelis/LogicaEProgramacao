﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Loja_Informatica_Pedro_d_Angelis
{
    internal class Classe_Produtos
    {
        public class Produtos
        {
            private int Id_Produto;
            private string Descricao;
            private string Categoria;
            private string Preco_Compra;
            private string Preco_Venda;
            private string Qtd_Estoque;

            public int id_produto { get; set; }
            public string descricao { get; set;}
            public string categoria { get; set;}
            public string preco_venda { get; set; }
            public string preco_compra { get; set; }
            public string qtd_estoque { get; set; }

        }
    }
}

// idProduto, descricao, categoria, precoCompra, precoVenda, qtdeEstoque.