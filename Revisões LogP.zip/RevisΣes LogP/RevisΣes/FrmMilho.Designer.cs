﻿namespace Revisões
{
    partial class FrmMilho
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMilho = new System.Windows.Forms.Label();
            this.lblSuco = new System.Windows.Forms.Label();
            this.txtSucos = new System.Windows.Forms.TextBox();
            this.txtMilhos = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblResultado = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblMilho
            // 
            this.lblMilho.AutoSize = true;
            this.lblMilho.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMilho.Location = new System.Drawing.Point(27, 29);
            this.lblMilho.Name = "lblMilho";
            this.lblMilho.Size = new System.Drawing.Size(117, 42);
            this.lblMilho.TabIndex = 0;
            this.lblMilho.Text = "Milho:";
            // 
            // lblSuco
            // 
            this.lblSuco.AutoSize = true;
            this.lblSuco.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSuco.Location = new System.Drawing.Point(440, 29);
            this.lblSuco.Name = "lblSuco";
            this.lblSuco.Size = new System.Drawing.Size(114, 42);
            this.lblSuco.TabIndex = 1;
            this.lblSuco.Text = "Suco:";
            // 
            // txtSucos
            // 
            this.txtSucos.Location = new System.Drawing.Point(447, 85);
            this.txtSucos.Name = "txtSucos";
            this.txtSucos.Size = new System.Drawing.Size(173, 22);
            this.txtSucos.TabIndex = 2;
            // 
            // txtMilhos
            // 
            this.txtMilhos.Location = new System.Drawing.Point(34, 85);
            this.txtMilhos.Name = "txtMilhos";
            this.txtMilhos.Size = new System.Drawing.Size(173, 22);
            this.txtMilhos.TabIndex = 3;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(34, 221);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(189, 67);
            this.btnCalcular.TabIndex = 4;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado.Location = new System.Drawing.Point(441, 239);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(22, 32);
            this.lblResultado.TabIndex = 5;
            this.lblResultado.Text = ".";
            // 
            // Milho
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(678, 364);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtMilhos);
            this.Controls.Add(this.txtSucos);
            this.Controls.Add(this.lblSuco);
            this.Controls.Add(this.lblMilho);
            this.Name = "Milho";
            this.Text = "Milho";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMilho;
        private System.Windows.Forms.Label lblSuco;
        private System.Windows.Forms.TextBox txtSucos;
        private System.Windows.Forms.TextBox txtMilhos;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblResultado;
    }
}