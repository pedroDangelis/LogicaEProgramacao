﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Revisões
{
    public partial class FrmSalário : Form
    {
        public FrmSalário()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //Recolher/Criar valores

            float Salario = float.Parse(txtSalario.Text);
            float SalarioAumento;


            //Calcular e mostrar resultado

            SalarioAumento = ((Salario * 30) / 100) + Salario; 
            lblResultado.Text = SalarioAumento.ToString();



        }

        private void lblSalarioAumento_Click(object sender, EventArgs e)
        {

        }
    }
}
