﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Revisões
{
    public partial class FrmSolteiros : Form
    {
        public FrmSolteiros()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //Criar Variaveis 

            float Funcionarios = float.Parse(txtFuncionarios.Text);
            float Solteiros = float.Parse(txtSolteiros.Text);
            float Resultado;


            //Calcular e mostrar resultados

            Resultado = Solteiros / Funcionarios * 100;
            lblResultado.Text = ("A porcentagem de solteiros é: " + Resultado + "%");

        }

        private void Solteiros_Load(object sender, EventArgs e)
        {

        }
    }
}
