﻿namespace Revisões
{
    partial class FrmSolteiros
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblFuncionarios = new System.Windows.Forms.Label();
            this.lblSolteiros = new System.Windows.Forms.Label();
            this.txtFuncionarios = new System.Windows.Forms.TextBox();
            this.txtSolteiros = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblResultado = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblFuncionarios
            // 
            this.lblFuncionarios.AutoSize = true;
            this.lblFuncionarios.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFuncionarios.Location = new System.Drawing.Point(14, 143);
            this.lblFuncionarios.Name = "lblFuncionarios";
            this.lblFuncionarios.Size = new System.Drawing.Size(486, 42);
            this.lblFuncionarios.TabIndex = 0;
            this.lblFuncionarios.Text = "Quantidade de funcionários:";
            // 
            // lblSolteiros
            // 
            this.lblSolteiros.AutoSize = true;
            this.lblSolteiros.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSolteiros.Location = new System.Drawing.Point(14, 263);
            this.lblSolteiros.Name = "lblSolteiros";
            this.lblSolteiros.Size = new System.Drawing.Size(423, 42);
            this.lblSolteiros.TabIndex = 1;
            this.lblSolteiros.Text = "Quantidade de solteiros:";
            // 
            // txtFuncionarios
            // 
            this.txtFuncionarios.Location = new System.Drawing.Point(21, 204);
            this.txtFuncionarios.Name = "txtFuncionarios";
            this.txtFuncionarios.Size = new System.Drawing.Size(249, 22);
            this.txtFuncionarios.TabIndex = 2;
            // 
            // txtSolteiros
            // 
            this.txtSolteiros.Location = new System.Drawing.Point(21, 335);
            this.txtSolteiros.Name = "txtSolteiros";
            this.txtSolteiros.Size = new System.Drawing.Size(249, 22);
            this.txtSolteiros.TabIndex = 3;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(638, 162);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(164, 64);
            this.btnCalcular.TabIndex = 4;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado.Location = new System.Drawing.Point(15, 408);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(22, 32);
            this.lblResultado.TabIndex = 5;
            this.lblResultado.Text = ".";
            // 
            // Solteiros
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(906, 512);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtSolteiros);
            this.Controls.Add(this.txtFuncionarios);
            this.Controls.Add(this.lblSolteiros);
            this.Controls.Add(this.lblFuncionarios);
            this.Name = "Solteiros";
            this.Text = "Solteiros";
            this.Load += new System.EventHandler(this.Solteiros_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblFuncionarios;
        private System.Windows.Forms.Label lblSolteiros;
        private System.Windows.Forms.TextBox txtFuncionarios;
        private System.Windows.Forms.TextBox txtSolteiros;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblResultado;
    }
}