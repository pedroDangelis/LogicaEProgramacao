﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Revisões
{
    public partial class FrmMilho : Form
    {
        public FrmMilho()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {

            //Coisar variaveis

            float Milhos = float.Parse(txtMilhos.Text);
            float Sucos = float.Parse(txtSucos.Text);
            float Resultado;


            //Calcular e exibir o resultado

            Resultado = Milhos * 1.5f + Sucos * 2;
            lblResultado.Text = ("Valor a pagar: " + Resultado);

        }
    }
}
