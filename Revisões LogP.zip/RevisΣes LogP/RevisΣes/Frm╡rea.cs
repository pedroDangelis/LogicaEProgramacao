﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Revisões
{
    public partial class FrmÁrea : Form
    {
        public FrmÁrea()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //Receber Valores

            float pi = float.Parse(txtPi.Text); 
            float raio = float.Parse(txtRaio.Text);
            float area;

            //Calcular e mostrar resultado

            area = pi * (raio * raio);

            lblResultado.Text = ("A área do círculo é: " + area);



                
        }
    }
}
