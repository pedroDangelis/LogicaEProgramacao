﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExerciciosDeDecisao
{
    public partial class FrmExemplo01 : Form
    {
        public FrmExemplo01()
        {
            InitializeComponent();
        }

       

        private void exemplo1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmExemplo01 frmExemplo01 = new FrmExemplo01();
            frmExemplo01.Show();
            this.Hide();
        }

        private void exemplo2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmExemplo02 frmExemplo02 = new FrmExemplo02();
            frmExemplo02.Show();
            this.Hide();
        }

        private void exemplo3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmExemplo03 frmExemplo03 = new FrmExemplo03();
            frmExemplo03.Show();
            this.Hide();
        }
    }
}
